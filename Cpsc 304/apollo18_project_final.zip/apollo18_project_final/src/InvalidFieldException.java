public class InvalidFieldException extends Exception { // Custom exception to handle invalid fields

    public InvalidFieldException() {
        //new InvalidFieldGui();
    }
}
